<?php
require_once("connection.php");
session_start();
$flag = 0;

//print_r($_REQUEST);

if(!isset($_SESSION['admin']) || $_SESSION['admin']=="")	{
	print_r($_REQUEST);
	echo "<script>window.location='login.php';</script>";
}
elseif($_SESSION['admin'] == "true" && (isset($_REQUEST['txtOneFilingCharge']) && ($_REQUEST['txtOneFilingCharge']<>"")))	{
	//To update active status
	mysqli_query($con,"update filingCharges set active = 0");
	mysqli_query($con,"update coupons set active = 0");
	
	$query = "Insert into filingCharges(startDate,one,two,three,four,five,six,active) values('".$_REQUEST['txtFilingStartDate']."','".$_REQUEST['txtOneFilingCharge']."','".$_REQUEST['txtTwoFilingCharge']."','".$_REQUEST['txtThreeFilingCharge']."','".$_REQUEST['txtFourFilingCharge']."','".$_REQUEST['txtFiveFilingCharge']."','".$_REQUEST['txtSixFilingCharge']."','1')";
	$insertRes = mysqli_query($con,$query);
	//echo "<br>Qry: ".$query;

	if(isset($_REQUEST['txtCouponCode1']) && ($_REQUEST['txtCouponCode1'] <>"" ))	{
		$couponQuery = "Insert into coupons(couponCode,rate,startDate,endDate,active) values('".$_REQUEST['txtCouponCode1']."','".$_REQUEST['txtCoupon1Per']."','".$_REQUEST['datePickerC1StartDate']."','".$_REQUEST['datePickerC1EndDate']."','1')";
		$insertRes = mysqli_query($con,$couponQuery);
	}

	if(isset($_REQUEST['txtCouponCode2']) && ($_REQUEST['txtCouponCode2'] <>"" ))	{
		$couponQuery = "Insert into coupons(couponCode,rate,startDate,endDate,active) values('".$_REQUEST['txtCouponCode2']."','".$_REQUEST['txtCoupon2Per']."','".$_REQUEST['datePickerC2StartDate']."','".$_REQUEST['datePickerC2EndDate']."','1')";
		$insertRes = mysqli_query($con,$couponQuery);
	}

	if(isset($_REQUEST['txtCouponCode3']) && ($_REQUEST['txtCouponCode3'] <>"" ))	{
		$couponQuery = "Insert into coupons(couponCode,rate,startDate,endDate,active) values('".$_REQUEST['txtCouponCode3']."','".$_REQUEST['txtCoupon3Per']."','".$_REQUEST['datePickerC3StartDate']."','".$_REQUEST['datePickerC3EndDate']."','1')";
		$insertRes = mysqli_query($con,$couponQuery);
	}

	if(isset($_REQUEST['txtCouponCode4']) && ($_REQUEST['txtCouponCode4'] <>"" ))	{
		$couponQuery = "Insert into coupons(couponCode,rate,startDate,endDate,active) values('".$_REQUEST['txtCouponCode4']."','".$_REQUEST['txtCoupon4Per']."','".$_REQUEST['datePickerC4StartDate']."','".$_REQUEST['datePickerC4EndDate']."','1')";
		$insertRes = mysqli_query($con,$couponQuery);
	}

	if(isset($_REQUEST['txtCouponCode5']) && ($_REQUEST['txtCouponCode5'] <>"" ))	{
		$couponQuery = "Insert into coupons(couponCode,rate,startDate,endDate,active) values('".$_REQUEST['txtCouponCode5']."','".$_REQUEST['txtCoupon5Per']."','".$_REQUEST['datePickerC5StartDate']."','".$_REQUEST['datePickerC5EndDate']."','1')";
		$insertRes = mysqli_query($con,$couponQuery);
	}

	if(isset($_REQUEST['txtCouponCode6']) && ($_REQUEST['txtCouponCode6'] <>"" ))	{
		$couponQuery = "Insert into coupons(couponCode,rate,startDate,endDate,active) values('".$_REQUEST['txtCouponCode6']."','".$_REQUEST['txtCoupon6Per']."','".$_REQUEST['datePickerC6StartDate']."','".$_REQUEST['datePickerC6EndDate']."','1')";
		$insertRes = mysqli_query($con,$couponQuery);
	}

	$flag = 1;
}
?>
<!DOCTYPE html>
  <html>
    <head>  
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
      <title>Online IT Filing : Bank Information</title>

	  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	  <!-- CSS  -->      
      <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
      <!-- Font Awesome -->
      <link href="css/font-awesome.css" rel="stylesheet">
      <!-- Skill Progress Bar -->
      <link href="css/pro-bars.css" rel="stylesheet" type="text/css" media="all" />
      <!-- Owl Carousel -->
      <link rel="stylesheet" href="css/owl.carousel.css">
      <!-- Default Theme CSS File-->
      <link id="switcher" href="css/themes/blue-theme.css" type="text/css" rel="stylesheet" media="screen,projection"/>     
      <!-- Main css File -->
      <link href="style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
	  <!-- For datePicker	-->
	  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	  <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>

      <!-- Extra css & JS File -->
      <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
	  <script src="js/validation.js"></script>

      <!-- Font -->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  
	  <script>
		var $j = jQuery.noConflict();

		$j(function() {
			$j("#datePickerC1StartDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC1EndDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC2StartDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC2EndDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC3StartDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC3EndDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC4StartDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC4EndDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC5StartDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC5EndDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC6StartDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});
		$j(function() {
			$j("#datePickerC6EndDate").datepicker({
				changeMonth: false,
				changeYear: true,
				yearRange: "1950:2016",
				dateFormat: "yy-mm-dd",
				autoSize: true
			});
		});

	(function($,W,D)
	{
		var JQUERY4U = {};

		JQUERY4U.UTIL =
		{
			setupFormValidation: function()
			{
				//form validation rules
				$("#rates").validate({
					rules: {
						txtFilingStartDate: "required",
						txtOneFilingCharge: "required",
						txtTwoFilingCharge: "required",
						txtThreeFilingCharge: "required",
						txtFourFilingCharge: "required",
						txtFiveFilingCharge: "required",
						txtSixFilingCharge: "required"
					},
					messages: {
						txtFilingStartDate: "Please Enter Filing Start Date",
						txtOneFilingCharge: "Please Enter Filing Charges",
						txtTwoFilingCharge: "Please Enter Filing Charges",
						txtThreeFilingCharge: "Please Enter Filing Charges",
						txtFourFilingCharge: "Please Enter Filing Charges",
						txtFiveFilingCharge: "Please Enter Filing Charges",
						txtSixFilingCharge: "Please Enter Filing Charges"
					},
					submitHandler: function(form) {
						form.submit();
					}
				});
			}
		}

		//when the dom has loaded setup form validation rules
		$(D).ready(function($) {
			JQUERY4U.UTIL.setupFormValidation();
		});

	})(jQuery, window, document);
	</script>
	</head>    

    <body>
      <!-- BEGAIN PRELOADER -->         
      <div id="preloader">        
        <div class="progress">
          <div class="indeterminate"></div>
        </div>        
      </div>
      <!-- END PRELOADER -->
      <header id="header" role="banner">
        <div class="navbar-fixed">
          <nav>
            <div class="container">
              <div class="nav-wrapper">
                <!-- LOGO -->

                <!-- TEXT BASED LOGO -->
                <a href="index.html" class="brand-logo">Online IT Filing : Terms &amp; COndition</a>
                
                <!-- Image Based Logo -->                
                 <!-- <a href="index.html" class="brand-logo"><img src="img/logo.jpeg" alt="logo img"></a>  -->
                <ul class="right hide-on-med-and-down custom-nav">                 
                  <li><a href="index.html">Home</a></li>
                  <li class="active"><a href="blog-archive.html">Blog</a></li>                  
                </ul>
                <!-- For Mobile View -->
                <ul id="slide-out" class="side-nav menu-scroll">
                  <li><a href="index.html">Home</a></li>
                  <li><a href="blog-archive.html">Blog</a></li>
                </ul>
                <a href="#" data-activates="slide-out" class="button-collapse"><i class="mdi-navigation-menu"></i></a>
              </div>
            </div>
          </nav>
        </div>  
      </header>
      <div class="main-wrapper">
        <main role="main">
          <!-- START BLOG BANNER -->
          <section id="banner">
            <div class="parallax-container">
              <div class="parallax">
                <img src="img/blog-header-bg.jpg">
              </div>
              <div class="overlay-header">       
              </div>
            </div>
          </section>
          <section id="blog-details">
            <div class="container">
              <div class="row">
                <div class="col s28 m18 28">
                  <div class="blog-content">
				  <form name="rates" id="rates" method="POST">
				  <h2 class="title">Admin Panel</h2>

				  <p>
				  <?php if($flag == 1)	{
						echo "Records updated successfully";
				  }	?>
				  </p>

					<p>
						<div class="form-group">
							<div style="float:left;">
								<div><label class="col-sm-2 control-label input-sm" for="textinput">Filing Charges for - </label></div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Start Date:</label>
									<div class="col-sm-3 has-success">
					 					<input type="text" id="datePickerFilingCharges" name="txtFilingStartDate" width="100px" value="<?php echo date("Y-m-d");?>" />
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label  input-sm" for="textinput">
										1:</label>
									<div class="col-sm-3">
										<input type="text" id="txtOneFilingCharge" placeholder="Enter Filing Charges" class="form-control  input-sm" name="txtOneFilingCharge">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										3:</label>
									<div class="col-sm-3">
										<input type="text" id="txtThreeFilingCharge" placeholder="Enter Filing Charges" class="form-control input-sm" maxlength="10" name="txtThreeFilingCharge">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										5:</label>
									<div class="col-sm-3">
										<input type="text" id="txtFiveFilingCharge" placeholder="Enter Filing Charges" class="form-control input-sm" maxlength="15" name="txtFiveFilingCharge">
									</div>
								</div>

								<div><label class="col-sm-2 control-label input-sm" for="textinput">Discount Coupons - </label></div>

								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 1:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCouponCode1" placeholder="Enter Coupon Code 1" class="form-control input-sm" 
										name="txtCouponCode1">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 1 - Start Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC1StartDate" placeholder="Enter Coupon Code 1 Start Date" class="form-control input-sm" name="datePickerC1StartDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 2:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCouponCode2" placeholder="Enter Coupon Code 2" class="form-control input-sm" 
										name="txtCouponCode2">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 2 - Start Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC2StartDate" placeholder="Enter Coupon Code 2 Start Date" class="form-control input-sm" name="datePickerC2StartDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 3:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCouponCode3" placeholder="Enter Coupon Code 3" class="form-control input-sm" 
										name="txtCouponCode3">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 3 - Start Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC3StartDate" placeholder="Enter Coupon Code 3 Start Date" class="form-control input-sm" name="datePickerC3StartDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 4:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCouponCode4" placeholder="Enter Coupon Code 4" class="form-control input-sm" 
										name="txtCouponCode4">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 4 - Start Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC4StartDate" placeholder="Enter Coupon Code 4 Start Date" class="form-control input-sm" name="datePickerC4StartDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 5:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCouponCode5" placeholder="Enter Coupon Code 5" class="form-control input-sm" 
										name="txtCouponCode5">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 5 - Start Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC5StartDate" placeholder="Enter Coupon Code 5 Start Date" class="form-control input-sm" name="datePickerC5StartDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 6:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCouponCode6" placeholder="Enter Coupon Code 6" class="form-control input-sm" 
										name="txtCouponCode6">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 6 - Start Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC6StartDate" placeholder="Enter Coupon Code 6 Start Date" class="form-control input-sm" name="datePickerC6StartDate">
									</div>
								</div>
							</div>
							<div style="float:right;margin-left:200px;">
								<div><p>&nbsp;</p></div>
								<div class="custgrp">
									<div class="col-sm-3 has-success">
										<p></p>
									</div>
								</div>
								<p><br><br></p>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										2:</label>
									<div class="col-sm-3">
										<input type="text" id="txtTwoFilingCharge" placeholder="Enter Filing Charges" class="form-control  input-sm"
											 name="txtTwoFilingCharge">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										4:</label>
									<div class="col-sm-3">
										<input type="text" id="txtFourFilingCharge" placeholder="Enter Filing Charges" class="form-control input-sm" maxlength="15" name="txtFourFilingCharge">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										6:</label>
									<div class="col-sm-3">
										<input type="text" id="txtSixFilingCharge" placeholder="Enter Filing Charges" class="form-control input-sm" maxlength="15" name="txtSixFilingCharge">
									</div>
								</div>
								
								<div>&nbsp;</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 1 - Percentage:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCoupon1Per" placeholder="Enter Coupon Code 1 Percentage" class="form-control input-sm" maxlength="15" name="txtCoupon1Per">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 1 - End Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC1EndDate" placeholder="Enter Coupon Code 1 End Date" class="form-control input-sm" name="datePickerC1EndDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 2 - Percentage:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCoupon2Per" placeholder="Enter Coupon Code 2 Percentage" class="form-control input-sm" maxlength="15" name="txtCoupon2Per">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 2 - End Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC2EndDate" placeholder="Enter Coupon Code 2 End Date" class="form-control input-sm" name="datePickerC2EndDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 3 - Percentage:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCoupon3Per" placeholder="Enter Coupon Code 3 Percentage" class="form-control input-sm" maxlength="15" name="txtCoupon3Per">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 3 - End Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC3EndDate" placeholder="Enter Coupon Code 3 End Date" class="form-control input-sm" name="datePickerC3EndDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 4 - Percentage:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCoupon4Per" placeholder="Enter Coupon Code 4 Percentage" class="form-control input-sm" maxlength="15" name="txtCoupon4Per">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 4 - End Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC4EndDate" placeholder="Enter Coupon Code 4 End Date" class="form-control input-sm" name="datePickerC4EndDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 5 - Percentage:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCoupon5Per" placeholder="Enter Coupon Code 5 Percentage" class="form-control input-sm" maxlength="15" name="txtCoupon5Per">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 5 - End Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC5EndDate" placeholder="Enter Coupon Code 5 End Date" class="form-control input-sm" name="datePickerC5EndDate">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 6 - Percentage:</label>
									<div class="col-sm-3">
										<input type="text" id="txtCoupon6Per" placeholder="Enter Coupon Code 6 Percentage" class="form-control input-sm" maxlength="15" name="txtCoupon6Per">
									</div>
								</div>
								<div class="custgrp">
									<label class="col-sm-2 control-label input-sm" for="textinput">
										Coupon Code 6 - End Date:</label>
									<div class="col-sm-3">
										<input type="text" id="datePickerC6EndDate" placeholder="Enter Coupon Code 6 End Date" class="form-control input-sm" name="datePickerC6EndDate">
									</div>
								</div>

							</div>
						</div>
					</p>
				</div>
				<p>
					<div align="center">
						<button class="left waves-effect btn-flat brand-text submit-btn" type="Submit" name="Submit" value="Submit">Submit</button>
						<button class="left waves-effect btn-flat brand-text submit-btn" type="Reset">Reset</button>
					</div>
				</p>
				</div>
			  </div> 	
            </div>
		   </div>
          </section>     
          <!-- Start Footer -->
          <footer id="footer" role="contentinfo">           
            <!-- Start Footer Bottom -->
            <div class="footer-bottom">
              <div class="container">
                <div class="row">
                  <div class="col s12">
                    <div class="footer-inner">
                      <!-- Bottom to Up Btn -->
                      <button class="btn-floating btn-large up-btn"><i class="mdi-navigation-expand-less"></i></button>
                      <p class="design-info"><div align=" <img src="img/ERI Authorized1.png">&nbsp;&nbsp;<img src="img/ERIAuthorized.png"> Privacy Policy&nbsp;&nbsp;&nbsp;&nbsp;Refund Policy &nbsp;&nbsp;&nbsp;&nbsp; General Terms & Conditions</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </footer>               
        </main>
      </div>
      <!-- jQuery Library -->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <!-- Materialize js -->
      <script type="text/javascript" src="js/materialize.min.js"></script>
      <!-- Skill Progress Bar -->
      <script src="js/appear.min.js" type="text/javascript"></script>
      <script src="js/pro-bars.min.js" type="text/javascript"></script>
      <!-- Owl slider -->      
      <script src="js/owl.carousel.min.js"></script>    
      <!-- Mixit slider  -->
      <script src="http://cdn.jsdelivr.net/jquery.mixitup/latest/jquery.mixitup.min.js"></script>
      <!-- counter -->
      <script src="js/waypoints.min.js"></script>
      <script src="js/jquery.counterup.min.js"></script>     

      <!-- Custom Js -->
      <script src="js/custom.js"></script>      
    </body>
  </html>