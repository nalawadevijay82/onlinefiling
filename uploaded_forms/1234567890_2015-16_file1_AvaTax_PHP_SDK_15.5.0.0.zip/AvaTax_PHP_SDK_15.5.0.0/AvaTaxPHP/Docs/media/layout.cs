#header {
	z-index:	100;
	position: 	absolute;
	top:		0px;
	left:		0px;
	width:		100%;
	height:		5%;
}
#nav {
	z-index:	200;
	position: 	absolute;
	top:		5%;
	left:		0px;
	width:		15%;
	height:		1600px;
	clip:		auto;
	overflow:	auto;
}
#body {
	position: 	absolute;
	top:		6%;
	left:		17%;
	width:		82%;
}
#content {
	clear:		both;
	top:		-1px;
}
#packagePosition {
	position:	absolute;
	right:		5px;
	top:		0px;
	width:		35%;
	height:		100%;
}
#packageTitle {
	position:	absolute;
	right:		0px;
}
#packageTitle2 {
	position:	absolute;
	right:		-3px;
	top:		-2px;
}
#elementPath {
	position:	absolute;
	right:		0px;
	bottom:		0px;
}
#navLinks {
	position:	absolute;
	top:		0px;
	left:		10px;
	height:		100%;

}
.leftCol {
	width:		auto;
	float:		left;
}
.middleCol {
	width:		auto;
	float:		left;
}
.rightCol {
	width:		auto;
	float:		left;
}
#credit {
	margin-top:	20px;
	margin-bottom:	50px;
}

/** Fixed layout for nav on mozilla */
head:first-child+body div#header {
	position:	fixed;
}
head:first-child+body div#nav {
	position:	fixed;
	height:		94%
}
