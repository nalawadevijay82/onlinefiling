<?php
/**
 * ApplyPaymentResult.class.php
 */

/**
 * 
 *
 * @author    Avalara
 * @copyright � 2004 - 2011 Avalara, Inc.  All rights reserved.
 * @package   Tax
 */

class ApplyPaymentResult extends BaseResult
{        
        
    
    
}

?>